.pragma library

// Pass language explicitly so changes invalidate the calling QML binding.
var languageCodes = ["en", "pt_PT", "pt_BR", "es"]
var languageNames = ["English", "Português (Portugal)", "Português (Brasil)", "Español"]

var messages = {
    "en": {
        "Idioma:": "Language:",
        "Geral": "General",
        "Comportamento do Num Lock": "Num Lock behavior",
        "Tela de Bloqueio:": "Lock screen:",
        "Ativar automaticamente o Num Lock quando a tela for bloqueada": "Automatically enable Num Lock when the screen is locked",
        "Inicialização:": "Startup:",
        "Garantir o Num Lock ativado ao iniciar a sessão do Plasma": "Ensure Num Lock is enabled when the Plasma session starts",
        "Notificações:": "Notifications:",
        "Exibir notificação popup ao forçar a ativação do Num Lock": "Show a notification when forcing Num Lock on",
        "Aparência e Painel": "Appearance and panel",
        "Outras teclas:": "Other keys:",
        "Mostrar indicador de Caps Lock no painel quando ativo": "Show the Caps Lock indicator in the panel when active",
        "Mostrar indicador de Scroll Lock no painel quando ativo": "Show the Scroll Lock indicator in the panel when active",
        "Tela de Login Inicial (SDDM)": "Login screen (SDDM)",
        "Para que o teclado numérico funcione antes mesmo de fazer login na máquina, execute o script de sincronização do SDDM.": "To enable the numeric keypad before logging in, run the SDDM synchronization script.",
        "Configurar SDDM Agora (requer sudo)": "Configure SDDM now (requires sudo)",
        "Num Lock Auto Locker": "Num Lock Auto Locker",
        "Configurações": "Settings",
        "Teclado Numérico (Num Lock)": "Numeric keypad (Num Lock)",
        "Ativado e pronto para uso": "Enabled and ready to use",
        "Desativado": "Disabled",
        "Caps Lock (Maiúsculas):": "Caps Lock (uppercase):",
        "LIGADO": "ON",
        "DESLIGADO": "OFF",
        "Scroll Lock:": "Scroll Lock:",
        "Automação de Bloqueio": "Lock automation",
        "Forçar Num Lock ao bloquear a tela": "Force Num Lock on when locking the screen",
        "Forçar Num Lock na inicialização da sessão": "Force Num Lock on at session startup",
        "Sincronizar com SDDM (Login)": "Synchronize with SDDM (login)",
        "Num Lock: %1": "Num Lock: %1",
        "Caps Lock: %1": "Caps Lock: %1",
        "ATIVADO": "ENABLED",
        "DESATIVADO": "DISABLED",
        "(Clique esquerdo: Menu | Clique do meio: Alternar)": "(Left click: Menu | Middle click: Toggle)",
        "Pressione Enter para fechar...": "Press Enter to close..."
    },
    "pt_PT": {
        "Idioma:": "Idioma:",
        "Geral": "Geral",
        "Comportamento do Num Lock": "Comportamento do Num Lock",
        "Tela de Bloqueio:": "Ecrã de bloqueio:",
        "Ativar automaticamente o Num Lock quando a tela for bloqueada": "Ativar automaticamente o Num Lock quando o ecrã for bloqueado",
        "Inicialização:": "Arranque:",
        "Garantir o Num Lock ativado ao iniciar a sessão do Plasma": "Garantir que o Num Lock está ativado ao iniciar a sessão do Plasma",
        "Notificações:": "Notificações:",
        "Exibir notificação popup ao forçar a ativação do Num Lock": "Mostrar uma notificação ao forçar a ativação do Num Lock",
        "Aparência e Painel": "Aparência e painel",
        "Outras teclas:": "Outras teclas:",
        "Mostrar indicador de Caps Lock no painel quando ativo": "Mostrar o indicador de Caps Lock no painel quando ativo",
        "Mostrar indicador de Scroll Lock no painel quando ativo": "Mostrar o indicador de Scroll Lock no painel quando ativo",
        "Tela de Login Inicial (SDDM)": "Ecrã de início de sessão (SDDM)",
        "Para que o teclado numérico funcione antes mesmo de fazer login na máquina, execute o script de sincronização do SDDM.": "Para que o teclado numérico funcione antes de iniciar sessão, execute o script de sincronização do SDDM.",
        "Configurar SDDM Agora (requer sudo)": "Configurar o SDDM agora (requer sudo)",
        "Num Lock Auto Locker": "Num Lock Auto Locker",
        "Configurações": "Definições",
        "Teclado Numérico (Num Lock)": "Teclado numérico (Num Lock)",
        "Ativado e pronto para uso": "Ativado e pronto a utilizar",
        "Desativado": "Desativado",
        "Caps Lock (Maiúsculas):": "Caps Lock (maiúsculas):",
        "LIGADO": "LIGADO",
        "DESLIGADO": "DESLIGADO",
        "Scroll Lock:": "Scroll Lock:",
        "Automação de Bloqueio": "Automatização do bloqueio",
        "Forçar Num Lock ao bloquear a tela": "Forçar o Num Lock ao bloquear o ecrã",
        "Forçar Num Lock na inicialização da sessão": "Forçar o Num Lock ao iniciar a sessão",
        "Sincronizar com SDDM (Login)": "Sincronizar com o SDDM (início de sessão)",
        "Num Lock: %1": "Num Lock: %1",
        "Caps Lock: %1": "Caps Lock: %1",
        "ATIVADO": "ATIVADO",
        "DESATIVADO": "DESATIVADO",
        "(Clique esquerdo: Menu | Clique do meio: Alternar)": "(Clique esquerdo: Menu | Clique do meio: Alternar)",
        "Pressione Enter para fechar...": "Prima Enter para fechar..."
    },
    "pt_BR": {
        "Idioma:": "Idioma:",
        "Geral": "Geral",
        "Comportamento do Num Lock": "Comportamento do Num Lock",
        "Tela de Bloqueio:": "Tela de Bloqueio:",
        "Ativar automaticamente o Num Lock quando a tela for bloqueada": "Ativar automaticamente o Num Lock quando a tela for bloqueada",
        "Inicialização:": "Inicialização:",
        "Garantir o Num Lock ativado ao iniciar a sessão do Plasma": "Garantir o Num Lock ativado ao iniciar a sessão do Plasma",
        "Notificações:": "Notificações:",
        "Exibir notificação popup ao forçar a ativação do Num Lock": "Exibir notificação popup ao forçar a ativação do Num Lock",
        "Aparência e Painel": "Aparência e Painel",
        "Outras teclas:": "Outras teclas:",
        "Mostrar indicador de Caps Lock no painel quando ativo": "Mostrar indicador de Caps Lock no painel quando ativo",
        "Mostrar indicador de Scroll Lock no painel quando ativo": "Mostrar indicador de Scroll Lock no painel quando ativo",
        "Tela de Login Inicial (SDDM)": "Tela de Login Inicial (SDDM)",
        "Para que o teclado numérico funcione antes mesmo de fazer login na máquina, execute o script de sincronização do SDDM.": "Para que o teclado numérico funcione antes mesmo de fazer login na máquina, execute o script de sincronização do SDDM.",
        "Configurar SDDM Agora (requer sudo)": "Configurar SDDM Agora (requer sudo)",
        "Num Lock Auto Locker": "Num Lock Auto Locker",
        "Configurações": "Configurações",
        "Teclado Numérico (Num Lock)": "Teclado Numérico (Num Lock)",
        "Ativado e pronto para uso": "Ativado e pronto para uso",
        "Desativado": "Desativado",
        "Caps Lock (Maiúsculas):": "Caps Lock (Maiúsculas):",
        "LIGADO": "LIGADO",
        "DESLIGADO": "DESLIGADO",
        "Scroll Lock:": "Scroll Lock:",
        "Automação de Bloqueio": "Automação de Bloqueio",
        "Forçar Num Lock ao bloquear a tela": "Forçar Num Lock ao bloquear a tela",
        "Forçar Num Lock na inicialização da sessão": "Forçar Num Lock na inicialização da sessão",
        "Sincronizar com SDDM (Login)": "Sincronizar com SDDM (Login)",
        "Num Lock: %1": "Num Lock: %1",
        "Caps Lock: %1": "Caps Lock: %1",
        "ATIVADO": "ATIVADO",
        "DESATIVADO": "DESATIVADO",
        "(Clique esquerdo: Menu | Clique do meio: Alternar)": "(Clique esquerdo: Menu | Clique do meio: Alternar)",
        "Pressione Enter para fechar...": "Pressione Enter para fechar..."
    },
    "es": {
        "Idioma:": "Idioma:",
        "Geral": "General",
        "Comportamento do Num Lock": "Comportamiento de Num Lock",
        "Tela de Bloqueio:": "Pantalla de bloqueo:",
        "Ativar automaticamente o Num Lock quando a tela for bloqueada": "Activar Num Lock automáticamente al bloquear la pantalla",
        "Inicialização:": "Inicio:",
        "Garantir o Num Lock ativado ao iniciar a sessão do Plasma": "Asegurar que Num Lock esté activado al iniciar la sesión de Plasma",
        "Notificações:": "Notificaciones:",
        "Exibir notificação popup ao forçar a ativação do Num Lock": "Mostrar una notificación al forzar la activación de Num Lock",
        "Aparência e Painel": "Apariencia y panel",
        "Outras teclas:": "Otras teclas:",
        "Mostrar indicador de Caps Lock no painel quando ativo": "Mostrar el indicador de Caps Lock en el panel cuando esté activo",
        "Mostrar indicador de Scroll Lock no painel quando ativo": "Mostrar el indicador de Scroll Lock en el panel cuando esté activo",
        "Tela de Login Inicial (SDDM)": "Pantalla de inicio de sesión (SDDM)",
        "Para que o teclado numérico funcione antes mesmo de fazer login na máquina, execute o script de sincronização do SDDM.": "Para que el teclado numérico funcione antes de iniciar sesión, ejecute el script de sincronización de SDDM.",
        "Configurar SDDM Agora (requer sudo)": "Configurar SDDM ahora (requiere sudo)",
        "Num Lock Auto Locker": "Num Lock Auto Locker",
        "Configurações": "Configuración",
        "Teclado Numérico (Num Lock)": "Teclado numérico (Num Lock)",
        "Ativado e pronto para uso": "Activado y listo para usar",
        "Desativado": "Desactivado",
        "Caps Lock (Maiúsculas):": "Caps Lock (mayúsculas):",
        "LIGADO": "ACTIVADO",
        "DESLIGADO": "DESACTIVADO",
        "Scroll Lock:": "Scroll Lock:",
        "Automação de Bloqueio": "Automatización del bloqueo",
        "Forçar Num Lock ao bloquear a tela": "Forzar Num Lock al bloquear la pantalla",
        "Forçar Num Lock na inicialização da sessão": "Forzar Num Lock al iniciar la sesión",
        "Sincronizar com SDDM (Login)": "Sincronizar con SDDM (inicio de sesión)",
        "Num Lock: %1": "Num Lock: %1",
        "Caps Lock: %1": "Caps Lock: %1",
        "ATIVADO": "ACTIVADO",
        "DESATIVADO": "DESACTIVADO",
        "(Clique esquerdo: Menu | Clique do meio: Alternar)": "(Clic izquierdo: Menú | Clic central: Alternar)",
        "Pressione Enter para fechar...": "Pulse Intro para cerrar..."
    }
}

function normalizeLanguage(language) {
    return languageCodes.indexOf(language) >= 0 ? language : "en"
}

function tr(language, source, argument) {
    var catalog = messages[normalizeLanguage(language)]
    var text = catalog[source] || messages.en[source] || source
    return argument === undefined ? text : text.replace(/%1/g, function() { return String(argument) })
}

// Quote each shell argument, including paths containing spaces or apostrophes.
function shellQuote(value) {
    return "'" + String(value).replace(/'/g, "'\"'\"'") + "'"
}

function sddmCommand(scriptPath, language) {
    var command = "pkexec bash " + shellQuote(scriptPath)
        + " --language " + shellQuote(normalizeLanguage(language))
        + "; printf '\\n%s\\n' " + shellQuote(tr(language, "Pressione Enter para fechar..."))
        + "; read -r"
    return "konsole -e bash -c " + shellQuote(command)
}
